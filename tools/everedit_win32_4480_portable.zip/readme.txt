■ NO WARRANTY
EverEdit IS SOLD “AS IS” AND WITHOUT ANY WARRANTY AS TO MERCHANTABILITY OR FITNE
SS FOR A PARTICULAR PURPOSE OR ANY OTHER WARRANTIES EITHER EXPRESSED OR IMPLIED.
THE AUTHOR WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR ANY OTH
ER KIND OF LOSS WHILE USING OR MISUSING THIS SOFTWARE.

■ Evaluation and Purchase
EverEdit is a shareware. You may use this software for evaluation purposes witho
ut charge for a period of 30 days. If you use this software after the 30 days ev
aluation period, you must buy a license.

■ Distribution
You are hereby licensed to make as many copies of the installation package for T
he Software as you wish; give exact copies of the original installation package 
for The Software to anyone; and distribute the original installation package for
The Software in its unmodified form via electronic or other means. The Software 
must be clearly identified as an evaluation version where described.
You are specifically prohibited from charging, or requesting donations, for any 
such copies, however made; and from distributing The Software including document
ation with other products (commercial or otherwise) without prior written permis
sion from www.EverEdit.net. You are also prohibited from distributing components
of The Software other than the complete original installation package.

■ Licensed Copy
One licensed copy can only be used by a single user on one or more computers. If
multiple users need to use EverEdit on a single workstation, you should buy more
licenses.